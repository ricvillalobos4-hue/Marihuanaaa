# Menú

Página web estática (HTML + CSS + JS, sin dependencias).

## Publicar en GitHub Pages
1. Sube todo el contenido de esta carpeta a un repositorio nuevo.
2. En el repo: **Settings → Pages → Build and deployment**.
3. Source: **Deploy from a branch** → Branch: `main` / carpeta `/ (root)` → **Save**.
4. En 1–2 minutos estará en `https://TU-USUARIO.github.io/NOMBRE-DEL-REPO/`.

## Configuración (dentro de `index.html`)
- `TIENDA.whatsapp`: tu número con lada para los pedidos.
- `IA_CONFIG`: datos de tu API de IA. **No subas una `apiKey` a un repo público**; úsala desde un servidor propio.
